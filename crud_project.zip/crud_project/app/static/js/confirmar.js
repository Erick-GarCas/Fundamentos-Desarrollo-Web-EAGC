function confirmarEliminacion(){
    return confirm("¿Estás seguro de que deseas eliminar este registro?");
}